<?php

namespace App\Controllers;

class Auth extends BaseController
{
    public function index()
    {
        $data = ['title' => 'Inicio'];
        return view('templates/header', $data)
            . view('auth/index')
            . view('templates/footer');
    }
}