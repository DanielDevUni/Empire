<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap demo</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="<?= base_url('public/assets/css/main.css') ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    </head>
    <body style="background-color: #f9f9f9;">
        <div class="header-container position-relative">
            <div class="position-absolute top-50 start-50 translate-middle text-title">
                Imperio Habbo
            </div>
            <div class="position-absolute text-center card info-employed text-wrap fw-medium">
                1258 empleados
            </div>
            <img src="<?= base_url('public/assets/images/static/skins_star.png') ?>" alt="Star" class="star" role="presentation" style="top: 10%; left: 30%; animation-delay: 0s;">
            <img src="<?= base_url('public/assets/images/static/skins_star.png') ?>" alt="Star" class="star" role="presentation" style="top: 70%; left: 40%; animation-delay: 1s;">
            <img src="<?= base_url('public/assets/images/static/skins_star.png') ?>" alt="Star" class="star" role="presentation" style="top: 50%; left: 80%; animation-delay: 2s;">
            <img src="<?= base_url('public/assets/images/static/skins_star.png') ?>" alt="Star" class="star" role="presentation" style="top: 20%; left: 60%; animation-delay: 0.5s;">
            <img src="<?= base_url('public/assets/images/static/skins_star.png') ?>" alt="Star" class="star" role="presentation" style="top: 60%; left: 95%; animation-delay: 1.5s;">
            <img src="<?= base_url('public/assets/images/static/skins_star.png') ?>" alt="Star" class="star" role="presentation" style="top: 50%; left: 10%; animation-delay: 2.5s;">
        </div>
        <nav class="navbar navbar-expand-lg" style="background-color#fff !important; box-shadow: 0 10px 40px rgba(71,69,156,.08);">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Bootstrap_logo.svg/768px-Bootstrap_logo.svg.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Bootstrap
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Dropdown
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                    </li>
                </ul>
                <div class="d-flex">
                    <button class="btn btn-main">Entrar</button>
                    <button class="btn btn-outline-dark ms-2">Registrarse</button>
                </div>
                </div>
            </div>
        </nav>
        <div class="container">