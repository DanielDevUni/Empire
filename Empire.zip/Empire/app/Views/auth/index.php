<div class="row pt-5">
    <div class="col-md-4">
        <h4>Buttons</h4>
        <hr>
        <button class="btn btn-main">Example</button>
        <button class="btn btn-dark">Example</button>
        <button class="btn btn-second">Example</button>
        <hr>

        <button class="btn btn-outline-main">Example</button>
        <button class="btn btn-outline-dark">Example</button>
        <button class="btn btn-outline-second">Example</button>

        <hr>
        <div class="d-grid gap-2">
            <button class="btn btn-main" type="button">Button</button>
            <button class="btn btn-dark" type="button">Button</button>
            <button class="btn btn-second" type="button">Button</button>
        </div>
        <hr>
        <div class="btn-group" role="group" aria-label="Default button group">
            <button type="button" class="btn btn-outline-main">Left</button>
            <button type="button" class="btn btn-outline-main">Middle</button>
            <button type="button" class="btn btn-outline-main">Right</button>
        </div>
        <div class="btn-group" role="group" aria-label="Default button group">
            <button type="button" class="btn btn-outline-dark">Left</button>
            <button type="button" class="btn btn-outline-dark">Middle</button>
            <button type="button" class="btn btn-outline-dark">Right</button>
        </div>
        <div class="btn-group fragment" role="group" aria-label="Default button group">
            <button type="button" class="btn btn-outline-second">Left</button>
            <button type="button" class="btn btn-outline-second">Middle</button>
            <button type="button" class="btn btn-outline-second">Right</button>
        </div>
        
        <h4 class="fragment">Badges</h4>
        <hr>
        <span class="badge rounded-pill text-bg-primary">Primary</span>
        <span class="badge rounded-pill text-bg-secondary">Secondary</span>
        <span class="badge rounded-pill text-bg-success">Success</span>
        <span class="badge rounded-pill text-bg-danger">Danger</span>
        <span class="badge rounded-pill text-bg-warning">Warning</span>
        <span class="badge rounded-pill text-bg-info">Info</span>
        <span class="badge rounded-pill text-bg-dark">Dark</span>
        <span class="badge rounded-pill text-bg-main">Main</span>
        <span class="badge rounded-pill text-bg-second">Second</span>
        
        <h4 class="fragment">Breadcumb</h4>
        <hr>
        <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: '/';">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Library</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data</li>
            </ol>
        </nav>
        <h4 class="fragment">ToolTips</h4>
        <button type="button" class="btn btn-main btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Tooltip on bottom">
            Tooltip on bottom
        </button>
        <button type="button" class="btn btn-dark btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Tooltip on bottom">
            Tooltip on bottom
        </button>
        <button type="button" class="btn btn-second btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Tooltip on bottom">
            Tooltip on bottom
        </button>
        <h4 class="fragment">Toasts</h4>
        <hr>
        <!-- Botón 1 -->
        <button type="button" class="btn btn-main btn-sm" id="liveToastBtn1">Show live toast 1</button>

        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div id="liveToast1" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <img src="https://styles.redditmedia.com/t5_2vhul/styles/communityIcon_wky86ucx32j21.png" width="20px" class="rounded me-2" alt="...">
                    <strong class="me-auto">Nuevo mensaje</strong>
                    <small>Hace 5 segundos</small>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    Usted ha sido ascendido.
                </div>
            </div>
        </div>

        <!-- Botón 2 -->
        <button type="button" class="btn btn-dark btn-sm" id="liveToastBtn2">Show live toast 2</button>

        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div id="liveToast2" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <img src="https://pbs.twimg.com/profile_images/1171156993513533440/UD0JPqQ5_400x400.png" width="25px" class="rounded me-2" alt="...">
                    <strong class="me-auto">Nuevo mensaje</strong>
                    <small>Hace 5 segundos</small>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    Actividad sospechosa en su cuenta.
                </div>
            </div>
        </div>

        
    </div>
    <div class="col-md-8">
        <h4>Cards</h4>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <img src="https://store.supercell.com/_next/static/media/store-card-bs-1.f8708622.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-main btn-sm">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card card-main clearfix">
                    <div class="card-header"><i class="fa-solid fa-tags float-start"></i> Featured</div>
                    <div class="card-body">
                        <h5 class="card-title">Special title treatment</h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-main btn-sm">Go somewhere</a>
                    </div>
                </div>
            </div>

            <div class="col md-6 fragment">
                <div class="card card-second clearfix">
                    <div class="card-header"><i class="fa-solid fa-tags float-start"></i> Featured</div>
                    <div class="card-body">
                        <h5 class="card-title">Special title treatment</h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-second btn-sm">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="col md-6 fragment">
                <div class="card card-dark clearfix">
                    <div class="card-header"><i class="fa-solid fa-tags float-start"></i> Featured</div>
                    <div class="card-body">
                        <h5 class="card-title">Special title treatment</h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-dark btn-sm">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="col-md-12 fragment">
                <h4>Accordion</h4>
                <hr>
                <div class="accordion" id="accordionExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Accordion Item #1
                        </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Accordion Item #2
                        </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Accordion Item #3
                        </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 fragment">
                <h4>List</h4>
                <hr>
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">An item</li>
                            <li class="list-group-item">A second item</li>
                            <li class="list-group-item">A third item</li>
                            <li class="list-group-item">A fourth item</li>
                            <li class="list-group-item">And a fifth one</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 fragment">
                <h4>Alerts</h4>
                <hr> 
                <div class="alert alert-success" role="alert">
                    A simple success alert—check it out!
                </div>
                <div class="alert alert-danger" role="alert">
                    A simple danger alert—check it out!
                </div>
                <div class="alert alert-dark" role="alert">
                    A simple dark alert—check it out!
                </div>
            </div>
            <div class="col-md-6 fragment">
                <div class="card membership-card">
                    <div class="card-header position-relative">
                        <div class="shield-pattern">
                            <i class="fa-solid fa-shield-halved"></i>
                        </div>
                        <img src="https://www.habbo.es/habbo-imaging/badge/b09114s36037s43174s38174s5501129fc138a1fbd5e491ed120ccd6b3b01b.gif" class="membership-image pixel-border" alt="Membresía">
                        <div class="membership-ribbon">Regla Libre</div>
                        <div class="discount-ribbon">-25% OFF</div>
                    </div>
                    <div class="card-body">
                        <h5 class="price">
                            <span class="price-value">$25</span>
                            <span class="price-period">/ mes</span>
                        </h5>
                        <ul class="card-benefits list-unstyled">
                            <li><i class="fa-solid fa-crown"></i> Acceso a zonas exclusivas</li>
                            <li><i class="fa-solid fa-tshirt"></i> Trabajar sin uniforme</li>
                            <li><i class="fa-solid fa-music"></i> Bailar y efectos en sala</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    
</div>
    
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Botón 1 activa el Toast 1
        const toastTrigger1 = document.getElementById('liveToastBtn1');
        const toastLive1 = document.getElementById('liveToast1');

        if (toastTrigger1) {
            toastTrigger1.addEventListener('click', function () {
                const toast = new bootstrap.Toast(toastLive1);
                toast.show();
            });
        }

        // Botón 2 activa el Toast 2
        const toastTrigger2 = document.getElementById('liveToastBtn2');
        const toastLive2 = document.getElementById('liveToast2');

        if (toastTrigger2) {
            toastTrigger2.addEventListener('click', function () {
                const toast = new bootstrap.Toast(toastLive2);
                toast.show();
            });
        }
    });
</script>

    
    